banks-v11-2026-11-13 — manual deploy
=====================================
remote-devices MCP down, so these files didn't reach the Mac automatically.
Drop them into your local clone in these exact paths:

  landings/banks.page.html                    (replace)
  landings/banks.json                         (replace)
  public/banks/index.html                     (replace)
  public/logos/banks/tbc.png                  (new — BLUE TBC logo)
  public/logos/banks/bog.png                  (new — ORANGE BOG lion)
  public/logos/banks/nbg.png                  (new — NBG circular emblem)

Also DELETE these stale placeholder SVG files (committed in v09):
  public/logos/banks/tbc.svg
  public/logos/banks/bog.svg
  public/logos/banks/nbg.svg

Commit title:
  banks: v11 - real TBC/BOG/NBG logos + hero rewrite + stats centered + "20 წუთი, 100+ საათი"

Push via GitHub Desktop as usual.
